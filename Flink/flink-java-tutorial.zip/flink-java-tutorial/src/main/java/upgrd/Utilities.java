package upgrd;

import java.util.regex.Pattern;

public class Utilities {

    private static final String EMAIL_VALIDATION_REGEX = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*"+
        "@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

    /**
     * Validate email based on Regular expression
     * @param email
     * @return
     */
    public static boolean isValidEmail(String email)
    {
        Pattern pat = Pattern.compile(EMAIL_VALIDATION_REGEX);
        if (email == null)
            return false;
        return pat.matcher(email).matches();
    }
}
